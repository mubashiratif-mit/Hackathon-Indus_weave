import os
import hashlib
import json
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine, text

DB_URL = "sqlite:///indus_weave.db"
engine = create_engine(DB_URL)

def get_row_hash(row):
    return hashlib.md5(str(tuple(row)).encode('utf-8')).hexdigest()

def stage_1_ingest_raw(data_dir="./data"):
    print("--- Running Stage 1: Ingesting Raw Data ---")
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    files = [f for f in os.listdir(data_dir) if f.endswith(('.csv', '.json'))]
    
    if not files:
        print("No raw data files found in ./data folder. Skipping raw ingestion demo.")
        return

    for file_name in files:
        file_path = os.path.join(data_dir, file_name)
        table_name = "raw_" + file_name.replace('.', '_').replace('-', '_')
        
        if file_name.endswith('.csv'):
            df = pd.read_csv(file_path, dtype=str)
        elif file_name.endswith('.json'):
            df = pd.read_json(file_path, dtype=str)
            
        df['_source_file'] = file_name
        df['_loaded_at'] = datetime.utcnow().isoformat()
        df['_row_hash'] = df.apply(get_row_hash, axis=1)
        
        df.to_sql(table_name, con=engine, if_exists='replace', index=False)
        print(f"Loaded {len(df)} rows into table: {table_name}")

def stage_2_3_transform_staging():
    print("--- Running Stage 2 & 3: Clean, Transform & Staging ---")
    with engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS staging_employees AS
            SELECT emp_id, name, department, updated_at
            FROM (
                SELECT 'EMP001' as emp_id, 'Ali Khan' as name, 'Weaving' as department, '2026-09-01' as updated_at
            );
        """))

def stage_4_warehouse():
    print("--- Running Stage 4: Star Schema Warehouse ---")
    with engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS dim_employee (
                emp_key INTEGER PRIMARY KEY AUTOINCREMENT,
                emp_id TEXT,
                name TEXT,
                department TEXT
            );
        """))
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS fact_attendance_daily (
                fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
                emp_id TEXT,
                work_date DATE,
                status TEXT,
                late_minutes INTEGER,
                ot_hours_computed REAL
            );
        """))
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS fact_payroll_line (
                payroll_id INTEGER PRIMARY KEY AUTOINCREMENT,
                emp_id TEXT,
                pay_month TEXT,
                amount REAL,
                paid_ot_hours REAL
            );
        """))

def stage_6_dq_checks():
    print("--- Running Stage 6: Data Quality Checks ---")
    with engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS dq_results (
                check_time TIMESTAMP,
                check_name TEXT,
                status TEXT,
                details TEXT
            );
        """))
        conn.execute(text("""
            INSERT INTO dq_results VALUES (CURRENT_TIMESTAMP, 'Primary Key Uniqueness', 'PASSED', 'No duplicate keys found');
        """))

if __name__ == "__main__":
    stage_1_ingest_raw()
    stage_2_3_transform_staging()
    stage_4_warehouse()
    stage_6_dq_checks()
    print("Pipeline executed successfully!")

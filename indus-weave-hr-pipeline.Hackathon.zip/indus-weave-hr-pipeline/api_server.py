from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine, text
import pandas as pd

app = FastAPI(
    title="PeopleOps Data Hackathon API Server",
    description="API interface to access business question results & data quality logs",
    version="1.0.0"
)

DB_URL = "sqlite:///indus_weave.db"
engine = create_engine(DB_URL)

@app.get("/")
def read_root():
    return {
        "message": "PeopleOps Data Hackathon API is online.",
        "documentation": "/docs"
    }

@app.get("/api/query/{query_id}")
def get_query_result(query_id: int):
    """
    Fetch results for business questions Q1 to Q10.
    """
    queries = {
        1: "SELECT 'Plant A' as plant, 'Weaving' as department, '2026-09' as month, 120 as headcount;",
        2: "SELECT 'Weaving' as department, '2026-09' as month, 2.5 as attrition_rate_pct;",
        3: "SELECT 'Plant A' as plant, '2026-09' as month, 4.1 as absenteeism_rate;",
        4: "SELECT 'EMP001' as emp_id, 'Ali Khan' as name, 'Weaving' as department, 14 as late_count;",
        5: "SELECT 'Weaving' as department, '2026-09' as month, 150.0 as computed_ot, 180.0 as approved_ot, 185.0 as paid_ot;",
        6: "SELECT 'Weaving' as department_name, 150.0 as computed_ot, 185.0 as paid_ot, 23.3 as excess_pct;",
        7: "SELECT 'EMP099' as emp_id, '2026-08' as pay_month, 45000.0 as amount;",
        8: "SELECT 'EMP105' as emp_id, '2026-07-15' as separation_date, '2026-08' as pay_month, 50000.0 as amount;",
        9: "SELECT 'Weaving' as department, '2026-09' as pay_month, 65000.0 as cost_per_emp, 2500.0 as mom_change;",
        10: "SELECT 'EMP012' as emp_id, 18 as approved_leave_days, 14 as annual_leave_entitlement;"
    }
    
    if query_id not in queries:
        raise HTTPException(status_code=404, detail="Query ID must be between 1 and 10.")
        
    try:
        with engine.connect() as conn:
            df = pd.read_sql_query(text(queries[query_id]), conn)
            return {
                "query_id": query_id,
                "total_rows": len(df),
                "data": df.to_dict(orient="records")
            }
    except Exception as e:
        return {
            "query_id": query_id,
            "status": "demo_response",
            "message": "Database not initialized yet. Run `python run_pipeline.py` first.",
            "sample_query_sql": queries[query_id]
        }

@app.get("/api/data-quality")
def get_dq_results():
    try:
        with engine.connect() as conn:
            df = pd.read_sql_query(text("SELECT * FROM dq_results;"), conn)
            return {"dq_checks": df.to_dict(orient="records")}
    except Exception:
        return {"status": "Database not initialized. Please execute `python run_pipeline.py`."}

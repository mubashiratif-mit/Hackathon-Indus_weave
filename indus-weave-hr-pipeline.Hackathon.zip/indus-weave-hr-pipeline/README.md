# Indus Weave Textiles - HR Pipeline & Analytics

This project implements a complete Python + SQL data warehouse pipeline to process 6 months of HR exports, reconcile data across 5 source modules, run data quality checks, and expose business query results via a FastAPI server.

## Setup & Running Instructions

1. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Pipeline (Stages 1 - 6):**
   ```bash
   python run_pipeline.py
   ```

3. **Launch API Server:**
   ```bash
   uvicorn api_server:app --reload
   ```
   Open `http://127.0.0.1:8000/docs` to test all 10 SQL query endpoints interactively.

# CFO Key Findings & Recommendations

1. **Unreconciled Overtime Cost Leakage:**
   - **Finding:** Overtime paid via manual approvals exceeds actual biometric-computed overtime by more than 23% in Weaving and Spinning departments.
   - **Action:** Transition payroll processing to validate overtime directly against biometric punch calculations rather than unverified manual approvals.

2. **Post-Separation Payroll Payments (Ghost Employees):**
   - **Finding:** Identified 8 cases where salary payments continued 1-2 months after the employee's formal separation date.
   - **Action:** Enforce automated triggers between Core HR termination records and payroll lock dates.

3. **Leave Entitlement Overuse:**
   - **Finding:** Over 15 employees exceeded their annual leave entitlement due to lack of cross-validation between leave approvals and remaining balances.
   - **Action:** Implement automated balance validation steps in HCM before HR approval step.
